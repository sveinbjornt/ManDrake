/* ManDrakeController */

#import <Cocoa/Cocoa.h>

@interface ManDrakeController : NSObject
{
	IBOutlet id refreshProgressIndicator;
	IBOutlet id saveProgressIndicator;
    IBOutlet id editableTextField;
    IBOutlet id manPathTextField;
    IBOutlet id openButton;
    IBOutlet id preview;
    IBOutlet id refreshButton;
    IBOutlet id refreshPopupMenu;
    IBOutlet id saveAsButton;
    IBOutlet id saveButton;
    IBOutlet id scalePopupMenu;
	IBOutlet id window;
	IBOutlet id previewTextField;
	IBOutlet id webView;
	
	NSTimer *refreshTimer;
}
- (IBAction)open:(id)sender;
- (IBAction)refresh:(id)sender;
- (IBAction)revert:(id)sender;
- (IBAction)save:(id)sender;
- (IBAction)saveAs:(id)sender;
- (void)drawWebView;
- (void)updateView;
@end
