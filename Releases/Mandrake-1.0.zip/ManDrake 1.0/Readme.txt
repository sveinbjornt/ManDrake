README document for ManDrake version 1.0 11/06/2004


What is ManDrake?

ManDrake is a primitive WYSIWYG-style man page editor distributed under the GNU General Public License.  It is written in Objective C using the Cocoa application programming interfaces and runs on Mac OS X.  The source should accompany the program in cases of redistribution.  If you can't figure out how ManDrake works then you have no business writing man pages :D.

Version history

11/06/2004 - Version 1.0 released

Enjoy

Sveinbjorn Thordarson
http://sveinbjorn.vefsyn.is/software
<sveinbtNO@SPAM.hi.is>

